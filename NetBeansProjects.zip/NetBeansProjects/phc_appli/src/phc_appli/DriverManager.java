/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package phc_appli;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author mohan
 */
class DriverManager {

    static Connection getConnection(String jdbcmysqllocalhost3306phc_appliuseSSLfals, String root, String resh123456789) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
